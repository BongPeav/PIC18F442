/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 2, 2024, 7:34 AM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  40000000UL

#define RECEIVED     RCIF == 1

void uart_init(long baud){
    TRISC6=0;
    TRISC7=1;
    
    TXSTAbits.TXEN = 1;
    
    RCSTAbits.SPEN = 1;
    RCSTAbits.CREN = 1;
    SPBRG = ((_XTAL_FREQ/baud)/64) - 1;
}

void uart_send(uint8_t data){   
    TXREG = data; 
     while(TXIF==0);
}

uint8_t uart_receive(void){   
    while(RCIF==0);
    uint8_t data = RCREG;
    return data;
}

void uart_text(uint8_t *txt){
    while(*txt) uart_send(*txt++);
}

void main(void) {
    uart_init(19200);    
    PORTD=0;
    LATD=0;
    TRISD=0;    
    uart_text("PIC18F442 UART Example\r\n");
    while(1){        
        if(RECEIVED) {
            uint8_t data = uart_receive();
            LATD = data;
            uart_send(data);
            uart_send('\r');
            uart_send('\n');
            __delay_ms(10);
        }
        
    }
    return;
}
