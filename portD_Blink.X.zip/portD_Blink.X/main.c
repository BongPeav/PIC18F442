/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 30, 2024, 10:35 AM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  40000000UL

void main(void) {
    PORTD=0;
    LATD=0;
    TRISD=0;
    while(1){
        LATD=~LATD;
        __delay_ms(1000);
    }
    return;
}
