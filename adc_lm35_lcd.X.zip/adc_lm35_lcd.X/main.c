/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 1, 2024, 7:26 PM
 */

#include <xc.h>
#include "config.h"
#include "lcd.h"

#define _XTAL_FREQ  40000000UL

uint16_t adc_value = 0;
uint16_t adc_voltage = 0;
uint16_t text[16];

void adc_init(void){  
    /*Enable All Analog Input Pins*/
    TRISA=0xFF;
    TRISE=0x07;
    /*ADC Clock is Fosc/2, AN0 input, ADC ON*/
    ADCON0 = 0x01;
    /*Result is right justified, All Analog, VDD:VSS REF*/
    ADCON1 = 0x80;
}

uint16_t adc_read(uint8_t ANx){
    ADCON0bits.CHS = ANx;
    for(uint8_t i=0;i<10;i++);   
    ADCON0bits.GO = 1;
    while(ADCON0bits.GO);   
    uint16_t result = (ADRESH<<8) + ADRESL;
    return result;
}

void main(void) {
    lcd_init();
    adc_init();
    lcd_clear();
    lcd_xy(1,0);
    printf("PIC18F442 LM35");
    lcd_xy(2,1);
    printf("LCD Example");
    __delay_ms(5000);
    lcd_clear();
    printf("TEMPERATURE:");
    while(1){
        adc_value = adc_read(7);
        adc_voltage = (5000.0*adc_value)/1023;
        lcd_xy(0,1);
        printf("LM35: %3d.%1d%cC",adc_voltage/10,adc_voltage%10,223);
        __delay_ms(500);
    }
    return;
}
