/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 3, 2024, 10:19 AM
 */

#include <xc.h>
#include "config.h"
#include "i2c.h"
#include "lcd.h"

#define _XTAL_FREQ  40000000UL

const uint8_t DS3232_W = 0xD0;
const uint8_t DS3232_R = 0xD1;

struct RTC{
    uint8_t second;
    uint8_t minute;
    uint8_t hour;
    uint8_t day;
    uint8_t date;
    uint8_t month;
    uint8_t year;
};

struct RTC myTime;

uint8_t rtc_read(uint8_t address){
    i2c_start();
    i2c_write(DS3232_W);
    i2c_write(address);
    i2c_stop();
    
    i2c_start();
    i2c_write(DS3232_R);
    uint8_t data = i2c_read(0);
    i2c_stop();
    
    return data;
}

void rtc_write(uint8_t address, uint8_t data){
    i2c_start();
    i2c_write(DS3232_W);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();
}

uint8_t bcd_to_decimal(uint8_t bcd){
    uint8_t decimal = ((bcd>>4)*10) + (bcd&0x0F);
    return decimal;
}

uint8_t decimal_to_bcd(uint8_t data){
    return (((data/10)<<4)+(data%10));
}

void get_rtc(void){
    uint8_t data[7];
    for(uint8_t i=0;i<7;i++){
    i2c_start();
    i2c_write(DS3232_W);
    i2c_write(i);
    i2c_stop();
    
    i2c_start();
    i2c_write(DS3232_R);
     data[i] = i2c_read(0);
    i2c_stop();
    }
    myTime.second = bcd_to_decimal(data[0]);
    myTime.minute = bcd_to_decimal(data[1]);
    if(data[2]&0x40==1) data[2] = data[2]&0x1F;
    else data[2] = data[2] & 0x3F;
    myTime.hour = bcd_to_decimal(data[2]);
    myTime.day = bcd_to_decimal(data[3]);
    myTime.date = bcd_to_decimal(data[4]);
    myTime.month = bcd_to_decimal(data[5]);
    myTime.year = bcd_to_decimal(data[6]);
    
}

void main(void) {
    i2c_init(100000);
    lcd_init();
    
    lcd_clear();
    while(1){
        get_rtc();
        lcd_xy(0,0);
        printf("TIME: %02d:%02d:%02d",myTime.hour,
                myTime.minute, myTime.second);
        lcd_xy(0,1);
        printf("DATE: 20%02d/%02d/%02d",myTime.year,
                myTime.month, myTime.date);
        __delay_ms(500);
    }
    return;
}
