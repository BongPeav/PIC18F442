/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 31, 2024, 9:15 AM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  40000000UL

/*RB Interrupt On Change Is Set To Low Priority*/
void __interrupt(low_priority) _isr(void){
    if(RBIF&&RBIE){
        if(RB7==0) LATD7^=1;
        if(RB6==0) LATD6^=1;
        if(RB5==0) LATD5^=1;
        if(RB4==0) LATD4^=1;
        RBIF=0;
    }
}

void main(void) {
    /*PORTD AS OUTPUT*/
    PORTD=0;
    LATD=0;
    TRISD=0;
    
    /*RB7:RB4 AS OUTPUT*/
    PORTB=0;
    LATB=0;
    TRISB=0xF0;
    nRBPU=0;
    
    /*Enable RB Port Change Interrupt*/
    GIE=1;
    RBIE=1;
    RBIF=0;
    RBIP=0;
    while(1){
        LATD0^=1;
        __delay_ms(100);
    }
    return;
}
