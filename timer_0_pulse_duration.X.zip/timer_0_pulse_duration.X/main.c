/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 31, 2024, 4:30 PM
 */

#include <xc.h>
#include "config.h"
#include "lcd.h"

#define _XTAL_FREQ  40000000UL

uint8_t interrupt_count=0;
uint16_t press_duration=0;

void __interrupt(high_priority) T0ISR(void){
    if(T0IF){
        interrupt_count++;
        T0IF=0;
    }
}

void main(void) {
    lcd_init();
    LATB=0;
    PORTB=0;
    TRISB0=1;
    nRBPU=0;
    
    T0CONbits.TMR0ON=0;
    T0CONbits.T08BIT=0;
    T0CONbits.T0CS=0;
    T0CONbits.PSA=0;
    T0CONbits.T0PS=0;
    
    INTCONbits.GIE=1;
    INTCONbits.PEIE=1;
    INTCONbits.TMR0IE=1;
    INTCONbits.TMR0IF=0;
    TMR0H=0;
    TMR0L=0;
    printf("PRESS ON RB0 TO");
    lcd_xy(0,1);
    printf("MEASURE DURATION");
    while(1){
        if(RB0==0){
            T0CONbits.TMR0ON=1;
            lcd_clear();
            lcd_xy(0,0);
            printf("MEASURING LOGIC");
            lcd_xy(0,1);
            printf(" LOW DURATION");
            while(RB0==0);
            press_duration = interrupt_count * 13*2;
            lcd_clear();
            lcd_xy(0,0);
            printf("PRESS DURATION:");
            lcd_xy(0,1);
            printf("%6d mS",press_duration);
            T0CONbits.TMR0ON=0;
            press_duration=0;
            interrupt_count=0;
            TMR0H=0;
            TMR0L=0;
        }
    }
    return;
}
