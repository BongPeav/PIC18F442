/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 30, 2024, 6:52 PM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  40000000UL

/*High Priority Interrupt - Priority */
void __interrupt(high_priority) ext(void){
    /*Check External Interrupt 1*/
    if(INT1IF&&INT1IE){
        LATD1^=1;
        INT1IF=0;
    }
    /*Check External Interrupt 2*/
    if(INT2IF&&INT2IE){
        LATD2^=1;
        INT2IF=0;
    }
    /*Check External Interrupt 0 - INT0 is always high priority*/
    if(INT0IF&&INT0IE){
        LATD^=1;
        INT0IF=0;
    }
}

void main(void) {
    /*Clear PORTD and Set As Output*/
    PORTD=0;
    LATD=0;
    TRISD=0;
    /*Clear PORTB and Set RB2:RB0 As Input*/
    PORTB=0;
    LATB=0;
    TRISB=0x07;
    
    /*Turn On Pull-Up and Set Falling Edge of INT in INTCON2*/
    nRBPU=0;
    INTEDG0=0;
    INTEDG1=0;
    INTEDG2=0;
    
    /*Enable External Interrupt in INTCON*/
    INT0IE=1;
    GIE=1;
    
    /*Set INT Priority and other interrupts*/
    INT2IP=1;
    INT1IP=1;
    INT1IE=1;
    INT2IE=1;
    
    /*Clear Flag*/
    INT0IF=0;
    INT1IF=0;
    INT2IF=0;
    
    /*Clear LATD*/
    LATD=0;
    
    while(1){
        LATD7^=1;
        __delay_ms(100);
    }
    return;
}
