
#include "lcd.h"

void lcd_enable(char mode){
    RS = (mode==0)?0:1;
    EN = 1;
    __delay_us(100);
    EN = 0;
    __delay_us(100);
}

void lcd_command(uint8_t command){  
    DB = command&0xF0;
    lcd_enable(0);
    
    DB=command<<4;
    lcd_enable(0);
}

void lcd_data(uint8_t data){
    DB = data&0xF0;
    lcd_enable(1);
    DB = data<<4;
    lcd_enable(1);
}

void lcd_text(uint8_t *text){
    while(*text) lcd_data(*text++);
}

void lcd_clear(void){
    lcd_command(0x01);
    __delay_ms(10);
    lcd_command(0x0C);
}

void putch(char ch){
    lcd_data(ch);
}

void lcd_xy(uint8_t x, uint8_t y){
    uint8_t cursor[] = {0x80,0xC0};
    lcd_command(cursor[y]+x);
}

void lcd_init(void){
    DB = 0;
    DR = 0;
    lcd_command(0x33);
    lcd_command(0x32);
    lcd_command(0x28);
    lcd_command(0x0F);
    lcd_command(0x01);
    __delay_ms(10);
    lcd_command(0x06);
}
